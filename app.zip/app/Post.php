<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Post extends Model
{
    /**
     * mass assigment
     */
    protected $guarded = [];
}
