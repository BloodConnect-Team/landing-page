<?php return array (
  'post.artikel' => 'App\\Http\\Livewire\\Post\\Artikel',
  'post.create' => 'App\\Http\\Livewire\\Post\\Create',
  'post.edit' => 'App\\Http\\Livewire\\Post\\Edit',
  'post.index' => 'App\\Http\\Livewire\\Post\\Index',
);