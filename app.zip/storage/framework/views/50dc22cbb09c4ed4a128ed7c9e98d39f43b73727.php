

    <section class="pt-7">
        <div class="container">
        <div class="row align-items-center">
            <div class="col-md-6 text-md-start text-center py-6">
            <h1 class="mb-4 fs-9 fw-bold">BloodConnect. <br>Connected For Life</h1>
            <p class="mb-6 lead text-secondary">"Satu aplikasi hubungkan orang yang membutuhkan"<br>-BloodConnect Team</p>
            <div class="text-center text-md-start">
                <a href="#!" role="button">
                <img src="assets/img/icons/playstore.png" width="200px" alt="">
                </a>
            </div>
            <div class="d-flex align-items-center mt-6 justify-content-center justify-content-lg-start">
                <small class="me-2 fs-1 text-secondary">Supported By:</small>
                <img src="assets/img/icons/pmi.png" width="100px" alt="">
            </div>
            </div>
            <div class="col-md-6 text-end"><img class="pt-7 pt-md-0 img-fluid" src="assets/img/hero/hero-img.png" alt="" /></div>
        </div>
        </div>
    </section>

    <section class="pt-5 pt-md-9 mb-6" id="feature">
        <div class="bg-holder z-index--1 bottom-0 d-none d-lg-block" style="background-image:url(assets/img/category/shape.png);opacity:.5;">
        </div>
        <div class="container pb-5">
            <h1 class="fs-9 fw-bold mb-4 text-center"> Nikmati<br class="d-none d-xl-block" />fitur yang kami tawarkan</h1>
            <div class="row">
                <div class="col-lg-3 col-sm-6 mb-2"> <img class="mb-3 ms-n3" src="assets/img/category/icon1.png" width="75" alt="Feature" />
                <h4 class="mb-3">First click tests</h4>
                <p class="mb-0 fw-medium text-secondary">While most people enjoy casino gambling,</p>
                </div>
                <div class="col-lg-3 col-sm-6 mb-2"> <img class="mb-3 ms-n3" src="assets/img/category/icon2.png" width="75" alt="Feature" />
                <h4 class="mb-3">Design surveys</h4>
                <p class="mb-0 fw-medium text-secondary">Sports betting,lottery and bingo playing for the fun</p>
                </div>
                <div class="col-lg-3 col-sm-6 mb-2"> <img class="mb-3 ms-n3" src="assets/img/category/icon3.png" width="75" alt="Feature" />
                <h4 class="mb-3">Preference tests</h4>
                <p class="mb-0 fw-medium text-secondary">The Myspace page defines the individual.</p>
                </div>
                <div class="col-lg-3 col-sm-6 mb-2"> <img class="mb-3 ms-n3" src="assets/img/category/icon4.png" width="75" alt="Feature" />
                <h4 class="mb-3">Five second tests</h4>
                <p class="mb-0 fw-medium text-secondary">Personal choices and the overall personality of the person.</p>
                </div>
            </div>
        </div>
    </section>

    <section class="pt-5" id="validation">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                <div class="col-lg-12 text-center">
                    <h1 class="fw-bold mb-4 fs-7">Tech Stack</h1>
                    <p class="mb-5 text-info fw-medium">Teknologi yang kami gunakan</p>
                    <span><img src="https://upload.wikimedia.org/wikipedia/commons/thumb/9/9a/Laravel.svg/1200px-Laravel.svg.png" height="80" ></span>
                    <span><img src="https://logowik.com/content/uploads/images/flutter5786.jpg" height="80" ></span>
                    <span><img src="http://jwt.io/img/logo-asset.svg" height="80" ></span>
                    <span><img src="https://camo.githubusercontent.com/451061eb9714c2135705a1ad757017cc943627ca474d8a20e78209214469bf72/68747470733a2f2f6437756d7169637069373236332e636c6f756466726f6e742e6e65742f696d672f70726f647563742f65306364363161372d316336352d343561302d393765652d3737363364646335313533612f39383834313664302d323562632d346264322d623864622d6633343764306131393335642e706e67" height="80" ></span>
                    <span><img src="https://www.turnkeylinux.org/files/images/postgresql-logo-for-blog.png" height="80" ></span>
                </div>
            </div>
        </div>
    </section>

    <section class="pt-5 bg-red" id="marketing">
        <div class="container mt-5 pt-5 mb-5">
            <h1 class="fw-bold fs-6 mb-3 text-white">News</h1>
            <p class="mb-6 text-secondary text-white">Baca artikel menarik disini</p>
            <div class="row">
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4 mb-4">
                    <div class="card"><img class="card-img-top" src="assets/img/marketing/marketing01.png" alt="" />
                        <div class="card-body ps-0">
                        <p class="text-light">By <a class="fw-bold text-decoration-none me-1 text-white" href="#"><?php echo e($post->title); ?></a>|<span class="ms-1">03 March 2019</span></p>
                        <h3 class="fw-bold text-white"><?php echo e($post->content); ?></h3>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
<?php /**PATH D:\web\bloodconnect\landing\resources\views/livewire/post/index.blade.php ENDPATH**/ ?>